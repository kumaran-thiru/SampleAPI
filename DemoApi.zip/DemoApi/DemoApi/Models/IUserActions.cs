﻿namespace DemoApi.Models
{
    public interface IUserActions
    {
        bool IsValidUser(User user);
    }
}
